import { Link } from "react-router-dom";
import { ChartNoAxesCombined, Mail, ArrowRight } from "lucide-react";

export default function Footer() {
  return (
    <footer id="contact" className="bg-[#101D49] text-white">
      <div className="mx-auto max-w-7xl px-5 py-14 lg:px-8">
        <div className="grid gap-10 md:grid-cols-2 lg:grid-cols-4">
          <div>
            <Link to="/" className="flex items-center gap-3">
              <span className="flex h-11 w-11 items-center justify-center rounded-xl bg-white text-[#172B75]">
                <ChartNoAxesCombined size={24} />
              </span>
              <span className="text-2xl font-extrabold">
                Trade<span className="text-blue-300">Learn</span>
              </span>
            </Link>
            <p className="mt-5 max-w-xs text-sm leading-7 text-slate-300">
              Learn stock market fundamentals, technical analysis and investing
              concepts through structured online courses.
            </p>
          </div>

          <div>
            <h3 className="mb-5 font-bold">Explore</h3>
            <div className="space-y-3 text-sm text-slate-300">
              <Link to="/" className="block hover:text-white">
                Home
              </Link>
              <Link to="/courses" className="block hover:text-white">
                All Courses
              </Link>
              <a href="/#benefits" className="block hover:text-white">
                Why TradeLearn
              </a>
            </div>
          </div>

          <div>
            <h3 className="mb-5 font-bold">Learning Topics</h3>
            <div className="space-y-3 text-sm text-slate-300">
              <p>Stock Market Basics</p>
              <p>Technical Analysis</p>
              <p>Company Analysis</p>
              <p>Risk Management</p>
            </div>
          </div>

          <div>
            <h3 className="mb-5 font-bold">Start Learning</h3>
            <p className="mb-4 text-sm leading-6 text-slate-300">
              Build your financial knowledge at your own pace.
            </p>
            <Link
              to="/courses"
              className="inline-flex items-center gap-2 font-semibold text-blue-300 hover:text-white"
            >
              Explore Courses <ArrowRight size={17} />
            </Link>
            <p className="mt-5 flex items-center gap-2 text-sm text-slate-300">
              <Mail size={16} /> Learn. Practice. Grow.
            </p>
          </div>
        </div>

        <div className="mt-12 border-t border-white/15 pt-6 text-center text-sm text-slate-400">
          © {new Date().getFullYear()} TradeLearn. All rights reserved.
          <p className="mt-2 text-xs">
            Educational content is for learning purposes only and is not
            investment advice.
          </p>
        </div>
      </div>
    </footer>
  );
}
